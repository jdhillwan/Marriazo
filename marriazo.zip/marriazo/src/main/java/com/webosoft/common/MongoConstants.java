package com.webosoft.common;

public class MongoConstants {

	public static final String REGISTER_COLLECTION = "user";

}
