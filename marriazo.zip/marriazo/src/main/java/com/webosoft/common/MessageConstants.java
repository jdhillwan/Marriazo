package com.webosoft.common;

public class MessageConstants {

	public static final String REGISTER_SUCCESS = "Successfully Registered";
	public static final String REGISTER_ERROR = "Error in Registeration";
	
	public static final String RESPONSE_ERROR = "Error";
	public static final String RESPONSE_SUCCESS = "Success";
	

}
