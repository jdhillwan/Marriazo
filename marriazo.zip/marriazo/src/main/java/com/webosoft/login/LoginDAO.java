package com.webosoft.login;

public interface LoginDAO {

	UserDTO save(UserDTO userDto);

}
