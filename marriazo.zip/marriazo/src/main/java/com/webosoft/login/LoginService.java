package com.webosoft.login;

public interface LoginService {

	UserDTO register(UserDTO userDto);

}
